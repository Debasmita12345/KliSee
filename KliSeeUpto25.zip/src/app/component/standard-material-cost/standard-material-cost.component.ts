import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-standard-material-cost',
  templateUrl: './standard-material-cost.component.html',
  styleUrls: ['./standard-material-cost.component.css']
})
export class StandardMaterialCostComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
