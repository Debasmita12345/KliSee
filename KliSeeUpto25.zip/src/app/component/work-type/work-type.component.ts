import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-work-type',
  templateUrl: './work-type.component.html',
  styleUrls: ['./work-type.component.css']
})
export class WorkTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
