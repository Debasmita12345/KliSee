export interface IStandardMaterialCost{
    type_name: string;
    case_pack: string;
    cost_sf: string;
    case_cost_pack: string;
    shipping: string;
}