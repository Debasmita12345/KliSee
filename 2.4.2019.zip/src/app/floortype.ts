export interface IFloor{
    floor_id: string;
    floor_name: string;
}