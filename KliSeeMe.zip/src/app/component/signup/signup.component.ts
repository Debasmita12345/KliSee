import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SignUpService } from 'src/app/service/sign-up.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  myForm: FormGroup;
  show: boolean;
  // lists: any;

  constructor(public signupService: SignUpService) { 
    this.myForm=new FormGroup({
      name: new FormControl('', [Validators.required]),
      email: new FormControl ('', [Validators.required,Validators.email]),
      password: new FormControl('', [Validators.required]),
      password1: new FormControl('', [Validators.required]),
    })
  }
  
  ngOnInit() { 
    this.getList();
  }

  getList(){
    const user = {
      'first_name=' : this.myForm.value.name,
      'email=': this.myForm.value.email,
      'password=': this.myForm.value.password
    }
    this.signupService.getUserId(user).subscribe(res=>{
      console.log(res);
    })
  }

  onSubmit(){
    console.log(this.myForm)
    if (this.myForm.status==='VALID'){
      this.show=false;
    }
    else{
      this.show=true;
    }
  }

  hide = true;

}
