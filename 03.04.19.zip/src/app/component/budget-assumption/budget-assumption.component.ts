import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-budget-assumption',
  templateUrl: './budget-assumption.component.html',
  styleUrls: ['./budget-assumption.component.css']
})
export class BudgetAssumptionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
