export interface IModel{
    remodel_id: string;
    remodel_name: string;
}