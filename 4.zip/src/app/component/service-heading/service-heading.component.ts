import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-heading',
  templateUrl: './service-heading.component.html',
  styleUrls: ['./service-heading.component.css']
})
export class ServiceHeadingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
