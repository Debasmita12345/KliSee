export class IBudget{
    field_name: string;
    overall_cost: string;
    standard_cost: string;
    value: string;
}